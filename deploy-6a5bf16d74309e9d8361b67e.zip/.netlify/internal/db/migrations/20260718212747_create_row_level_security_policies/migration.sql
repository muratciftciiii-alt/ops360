CREATE TABLE "permissions" (
	"slug" text PRIMARY KEY,
	"resource" text NOT NULL,
	"action" text NOT NULL,
	"description" text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "role_permissions" (
	"role_slug" text,
	"permission_slug" text,
	CONSTRAINT "role_permissions_pkey" PRIMARY KEY("role_slug","permission_slug")
);
--> statement-breakpoint
CREATE TABLE "roles" (
	"slug" text PRIMARY KEY,
	"name" text NOT NULL UNIQUE,
	"description" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "security_audit_logs" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
	"actor_identity_user_id" text NOT NULL,
	"target_identity_user_id" text,
	"action" text NOT NULL,
	"details" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "user_profiles" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
	"identity_user_id" text NOT NULL UNIQUE,
	"name" text DEFAULT '' NOT NULL,
	"surname" text DEFAULT '' NOT NULL,
	"email" text NOT NULL UNIQUE,
	"phone" text DEFAULT '' NOT NULL,
	"department" text DEFAULT '' NOT NULL,
	"position" text DEFAULT '' NOT NULL,
	"profile_photo_url" text,
	"role_slug" text DEFAULT 'ofis_personeli' NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "role_permissions" ADD CONSTRAINT "role_permissions_role_slug_roles_slug_fkey" FOREIGN KEY ("role_slug") REFERENCES "roles"("slug") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "role_permissions" ADD CONSTRAINT "role_permissions_permission_slug_permissions_slug_fkey" FOREIGN KEY ("permission_slug") REFERENCES "permissions"("slug") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "user_profiles" ADD CONSTRAINT "user_profiles_role_slug_roles_slug_fkey" FOREIGN KEY ("role_slug") REFERENCES "roles"("slug");--> statement-breakpoint
INSERT INTO "roles" ("slug", "name", "description") VALUES
  ('yonetici', 'Yönetici', 'Tüm sistem ve kullanıcı yönetimi yetkileri'),
  ('mudur', 'Müdür', 'Operasyon modülleri ve rapor yönetimi'),
  ('ofis_personeli', 'Ofis Personeli', 'Ofis operasyonları ve doküman erişimi'),
  ('depo_personeli', 'Depo Personeli', 'Depo, görev ve teslimat operasyonları'),
  ('montaj_personeli', 'Montaj Personeli', 'Montaj, görev ve takvim operasyonları'),
  ('teslimat_personeli', 'Teslimat Personeli', 'Teslimat, görev ve takvim operasyonları');
--> statement-breakpoint
INSERT INTO "permissions" ("slug", "resource", "action", "description") VALUES
  ('dashboard.view', 'dashboard', 'view', 'Genel bakışı görüntüleme'),
  ('personnel.view', 'personnel', 'view', 'Personel sayfasını görüntüleme'),
  ('tasks.view', 'tasks', 'view', 'Görevleri görüntüleme'),
  ('deliveries.view', 'deliveries', 'view', 'Teslimatları görüntüleme'),
  ('installations.view', 'installations', 'view', 'Kurulumları görüntüleme'),
  ('calendar.view', 'calendar', 'view', 'Takvimi görüntüleme'),
  ('reports.view', 'reports', 'view', 'Raporları görüntüleme'),
  ('documents.view', 'documents', 'view', 'Dokümanları görüntüleme'),
  ('notifications.view', 'notifications', 'view', 'Bildirimleri görüntüleme'),
  ('settings.view', 'settings', 'view', 'Ayarları görüntüleme'),
  ('users.manage', 'users', 'manage', 'Kullanıcıları yönetme'),
  ('profile.update', 'profile', 'update', 'Kendi profilini güncelleme'),
  ('password.change', 'password', 'change', 'Kendi şifresini değiştirme');
--> statement-breakpoint
INSERT INTO "role_permissions" ("role_slug", "permission_slug")
SELECT 'yonetici', "slug" FROM "permissions";
--> statement-breakpoint
INSERT INTO "role_permissions" ("role_slug", "permission_slug") VALUES
  ('mudur', 'dashboard.view'), ('mudur', 'personnel.view'), ('mudur', 'tasks.view'),
  ('mudur', 'deliveries.view'), ('mudur', 'installations.view'), ('mudur', 'calendar.view'),
  ('mudur', 'reports.view'), ('mudur', 'documents.view'), ('mudur', 'notifications.view'),
  ('mudur', 'profile.update'), ('mudur', 'password.change'),
  ('ofis_personeli', 'dashboard.view'), ('ofis_personeli', 'tasks.view'),
  ('ofis_personeli', 'deliveries.view'), ('ofis_personeli', 'installations.view'),
  ('ofis_personeli', 'calendar.view'), ('ofis_personeli', 'reports.view'),
  ('ofis_personeli', 'documents.view'), ('ofis_personeli', 'notifications.view'),
  ('ofis_personeli', 'profile.update'), ('ofis_personeli', 'password.change'),
  ('depo_personeli', 'dashboard.view'), ('depo_personeli', 'tasks.view'),
  ('depo_personeli', 'deliveries.view'), ('depo_personeli', 'documents.view'),
  ('depo_personeli', 'notifications.view'), ('depo_personeli', 'profile.update'),
  ('depo_personeli', 'password.change'),
  ('montaj_personeli', 'dashboard.view'), ('montaj_personeli', 'tasks.view'),
  ('montaj_personeli', 'installations.view'), ('montaj_personeli', 'calendar.view'),
  ('montaj_personeli', 'documents.view'), ('montaj_personeli', 'notifications.view'),
  ('montaj_personeli', 'profile.update'), ('montaj_personeli', 'password.change'),
  ('teslimat_personeli', 'dashboard.view'), ('teslimat_personeli', 'tasks.view'),
  ('teslimat_personeli', 'deliveries.view'), ('teslimat_personeli', 'calendar.view'),
  ('teslimat_personeli', 'documents.view'), ('teslimat_personeli', 'notifications.view'),
  ('teslimat_personeli', 'profile.update'), ('teslimat_personeli', 'password.change');
--> statement-breakpoint
ALTER TABLE "roles" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "permissions" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "role_permissions" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "user_profiles" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "security_audit_logs" ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
CREATE POLICY "authenticated_roles_read" ON "roles" FOR SELECT
  USING (current_setting('app.identity_user_id', true) <> '');
CREATE POLICY "authenticated_permissions_read" ON "permissions" FOR SELECT
  USING (current_setting('app.identity_user_id', true) <> '');
CREATE POLICY "authenticated_role_permissions_read" ON "role_permissions" FOR SELECT
  USING (current_setting('app.identity_user_id', true) <> '');
CREATE POLICY "profiles_read_self_or_admin" ON "user_profiles" FOR SELECT
  USING (
    "identity_user_id" = current_setting('app.identity_user_id', true)
    OR current_setting('app.role', true) = 'yonetici'
  );
CREATE POLICY "profiles_update_self_or_admin" ON "user_profiles" FOR UPDATE
  USING (
    "identity_user_id" = current_setting('app.identity_user_id', true)
    OR current_setting('app.role', true) = 'yonetici'
  )
  WITH CHECK (
    "identity_user_id" = current_setting('app.identity_user_id', true)
    OR current_setting('app.role', true) = 'yonetici'
  );
CREATE POLICY "profiles_insert_admin" ON "user_profiles" FOR INSERT
  WITH CHECK (current_setting('app.role', true) = 'yonetici');
CREATE POLICY "audit_read_admin" ON "security_audit_logs" FOR SELECT
  USING (current_setting('app.role', true) = 'yonetici');
CREATE POLICY "audit_insert_admin" ON "security_audit_logs" FOR INSERT
  WITH CHECK (current_setting('app.role', true) = 'yonetici');
